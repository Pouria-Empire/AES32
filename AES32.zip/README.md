# ESP32 AES hardware encryption bindings
